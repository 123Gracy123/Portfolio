import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

import java.util.ArrayList;

/**
 * Write a description of class Ant here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Ant2 extends Actor
{
    private final int WEST = 180;
    private final int EAST = 0;
    private final int NORTH = 270;
    private final int SOUTH = 90;

    private final int DEGREE_LEFT = -90;
    private final int DEGREE_RIGHT = 90;
    private final int DEGREE_TURN_AROUND = 180;

    private int spacesMoved = 0;
    
    private  boolean canMoveForward() {
        MyWorld world = (MyWorld)this.getWorld();
        int rotation = this.getRotation();

        int offX = 0, offY = 0;

        switch (rotation) {
            case EAST:
                offX = 1;
                offY = 0;
                break;
            case WEST:
                offX = -1;
                offY = 0;
                break;
            case NORTH:
                offX = 0;
                offY = 1;
                break;
            case SOUTH:
                offX = 0;
                offY = -1;
                break;
        }

        System.out.printf("tileX: %d\n", offX);
        System.out.printf("tileY: %d\n", offY);

        int offXPx = getX() + (offX * world.SQUARE_SIZE);
        int offYPx = getY() - (offY * world.SQUARE_SIZE);

        // Normalize the offsets
        if (offXPx >= world.WORLD_MAX_X) {
            offXPx = world.WORLD_MAX_X;
        } else if (offXPx <= world.WORLD_MIN_X) {
            offXPx = world.WORLD_MIN_X;
        }

        if (offYPx >= world.WORLD_MAX_Y) {
            offYPx = world.WORLD_MAX_Y;
        } else if (offXPx <= world.WORLD_MIN_Y) {
            offYPx = world.WORLD_MIN_Y;
        }

        System.out.printf("offX: %d\n", offXPx);
        System.out.printf("offY: %d\n", offYPx);

        // This is trying to get colors outside of the world borders
        Color curSquareColor = world.getColorAt(offXPx, offYPx);
        System.out.printf("Checked color at (%d, %d), it's %s\n", offXPx, offYPx, curSquareColor.toString());

        return world.POSSIBLE_SQUARE_COLORS.contains(curSquareColor);
    }

    public boolean isOnQuestion() {
        MyWorld world = (MyWorld)this.getWorld();
        Color curSquareColor = world.getColorAt(getX(), getY());

        return world.QUESTION_SQUARE_COLOR.equals(curSquareColor);
    }

    private void findClearDirection() {
        // Turn to the left
        this.turn(this.DEGREE_LEFT);

        // If we hit a wall, keep turning right until an open spot is found
        while (!this.canMoveForward()) {
            this.turn(this.DEGREE_RIGHT);
        }
    }

    public void moveForward(int spacesToMove) {
        MyWorld world = (MyWorld)this.getWorld();
        System.out.println("Starting");

        if (spacesMoved + spacesToMove >= world.NUM_TILES) {
            spacesToMove = world.NUM_TILES - spacesMoved;
        }

        for (int i = 0; i < spacesToMove; i++) {
            System.out.println("loop");
            
            if (!canMoveForward()) {
                System.out.println("Couldn't move forward, finding direction");
                findClearDirection();
                System.out.println("Found good direction!");
            }

            spacesMoved++;
            move(world.SQUARE_SIZE);
        }

        String Q1 = "What stores objects in rows and columns?";
        String Q2 = "What do you call it when two or more methods have the same name but different parameters?";
        String Q3 = "What keyword is used to call a method in a parent class?";
        String Q4 = "What method calls itself from inside that method";
        String Q5 = "Is the following code declaring or creating an array? (int[][] ticketInfo)";
        String Q6 = "At what index is value 3 in the following code? (int[][] a = { {2, 4, 6, 8}, {1, 2, 3, 4} })";
        String Q7 = "What do you call a way to stop recursive calls?";
        String Q8 = "What is child a subclass of?";
        String Q9 = "What method returns the value of a field in an object?";
        String Q10 = "What do you call the runtime type of an object?"; 
        String [] Questions = {Q1, Q2, Q3, Q4, Q5, Q6, Q7, Q8, Q9, Q10};
        
        String A1 = "2D Arrays";
        String A2 = "Overload";
        String A3 = "Super";
        String A4 ="Recursion";
        String A5 ="Declaring";
        String A6 ="[1][2]";
        String A7 ="Base Case";
        String A8 ="Parent Class";
        String A9 ="Getter";
        String A10 ="Polymorphism";
        String [] Answers = {A1, A2, A3, A4, A5, A6, A7, A8, A9, A10};
        
        if (this.isOnQuestion()) {
            int ran = Greenfoot.getRandomNumber(Questions.length);
            String answer = Greenfoot.ask(Questions[ran]);
            if (Questions[ran].equals(Q1)) 
                {
                    if (answer.equals(A1))
                    {
                        moveForward(2);
                        //Greenfoot.ask("You're Correct!");
                    }
                    else
                    {
                        moveBackward(2);
                        //Greenfoot.ask("You're Wrong!");
                    }
                }
                else if (Questions[ran].equals(Q2))
                { 
                    if (answer.equals(A2))
                    { 
                        moveForward(2);
                        //Greenfoot.ask("You're Correct!");
                    }
                    else
                    {
                        moveBackward(2);
                        //Greenfoot.ask("You're Wrong!");
                    }
                }
                else if (Questions[ran].equals(Q3))
                { 
                    if (answer.equals(A3))
                    { 
                        moveForward(2);
                        //Greenfoot.ask("You're Correct!");
                    }
                    else
                    {
                        moveBackward(2);
                        //Greenfoot.ask("You're Wrong!");
                    }
                }
                else if (Questions[ran].equals(Q4))
                { 
                    if (answer.equals(A4))
                    { 
                        moveForward(2);
                        //Greenfoot.ask("You're Correct!");
                    }
                    else
                    {
                        moveBackward(2);
                        //Greenfoot.ask("You're Wrong!");
                    }
                }
                else if (Questions[ran].equals(Q5))
                { 
                    if (answer.equals(A5))
                    { 
                        moveForward(2);
                        //Greenfoot.ask("You're Correct!");
                    }
                    else
                    {
                        moveBackward(2);
                        //Greenfoot.ask("You're Wrong!");
                    }
                }
                else if (Questions[ran].equals(Q6))
                { 
                    if (answer.equals(A6))
                    { 
                        moveForward(2);
                        //Greenfoot.ask("You're Correct!");
                    }
                    else
                    {
                        moveBackward(2);
                        //Greenfoot.ask("You're Wrong!");
                    }
                }
                else if (Questions[ran].equals(Q7))
                { 
                    if (answer.equals(A7))
                    { 
                        moveForward(2);
                        //Greenfoot.ask("You're Correct!");
                    }
                    else
                    {
                        moveBackward(2);
                        //Greenfoot.ask("You're Wrong!");
                    }
                }
                else if (Questions[ran].equals(Q8))
                { 
                    if (answer.equals(A8))
                    { 
                        moveForward(2);
                        //Greenfoot.ask("You're Correct!");
                    }
                    else
                    {
                        moveBackward(2);
                        //Greenfoot.ask("You're Wrong!");
                    }
                }
                else if (Questions[ran].equals(Q9))
                { 
                    if (answer.equals(A9))
                    { 
                        moveForward(2);
                        //Greenfoot.ask("You're Correct!");
                    }
                    else
                    {
                        moveBackward(2);
                        //Greenfoot.ask("You're Wrong!");
                    }
                }
                else if (Questions[ran].equals(Q10))
                { 
                    if (answer.equals(A10))
                    { 
                        moveForward(2);
                        //Greenfoot.ask("You're Correct!");
                    }
                    else
                    {
                        moveBackward(2);
                        //Greenfoot.ask("You're Wrong!");
                    }
                }
        }

        System.out.println("Done!");
    }
    
    public void moveBackward(int spacesToMove) {
        this.turn(DEGREE_TURN_AROUND);
        this.moveForward(spacesToMove);
        this.turn(DEGREE_TURN_AROUND);

        this.spacesMoved -= spacesToMove;
    }

    public Ant2() {
        this.turn(NORTH);
        
    }
    
}
