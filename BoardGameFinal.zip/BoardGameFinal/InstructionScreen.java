import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class InstructionScreen here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class InstructionScreen extends World
{

    /**
     * Constructor for objects of class InstructionScreen.
     * 
     */
    public InstructionScreen()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
        prepare();
    }
    public void act()
    {
        String text = "The first player begins by rolling the first";
        String text2 = "and second dice by clicking on it. After";
        String text3 = "both of the dices are rolled, it is automatically";
        String text4 = "the second player's turn when they role the dice.";
        String text5 = "When the player lands on the blue tile, the player";
        String text6 = "will have a question pop up. If the";
        String text7 = "player answers correctly, they continue";
        String text8 = "to move ahead 2 steps. However, if they answer";
        String text9 = "incorrectly, the player moves back 2 steps. First";
        String text10 = "player to reach the end wins.";
        showText(text, 300, 40);
        showText(text2, 300, 70);
        showText(text3, 300, 100);
        showText(text4, 300, 130);
        showText(text5, 300, 160);
        showText(text6, 300, 190);
        showText(text7, 300, 220);
        showText(text8, 300, 250);
        showText(text9, 300, 280);
        showText(text10, 300, 310);
    }
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        BackButton backbutton = new BackButton();
        addObject(backbutton,300,370);
        backbutton.act();
    }
}
