import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.ArrayList;
import java.util.Arrays;

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{
    public final int SQUARE_SIZE = 32;
    public final int SQUARE_MIDDLE = SQUARE_SIZE / 2;

    public final Color NORMAL_SQUARE_COLOR = new Color(249, 122, 122);
    public final Color QUESTION_SQUARE_COLOR = new Color(124, 199, 254);
    public final ArrayList<Color> POSSIBLE_SQUARE_COLORS = new ArrayList<>(
        Arrays.asList(NORMAL_SQUARE_COLOR, QUESTION_SQUARE_COLOR)
    );
   
    private final int MIN_X = 0;
    private final int MIN_Y = 0;
    private final int MAX_X = 18;
    private final int MAX_Y = 12;
    
    public final int WORLD_MIN_X = 0;
    public final int WORLD_MAX_X = 576;
    public final int WORLD_MIN_Y = 0;
    public final int WORLD_MAX_Y = 382;

    public final int NUM_TILES = 47;
    public final int NUM_QUESTIONS = 10;

    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld() {
        // Create a new world with 576x382 cells with a cell size of 1x1 pixels.
        super(576, 383, 1);

        setBackground(new GreenfootImage("background.png"));

        prepare(); // Have to do this to use constants
    }

    private void prepare() {
        Ant ant = new Ant();
        Ant2 ant2 = new Ant2();

        this.addObject(ant2, SQUARE_MIDDLE, WORLD_MAX_Y - SQUARE_MIDDLE);
        this.addObject(ant, SQUARE_MIDDLE, WORLD_MAX_Y - SQUARE_MIDDLE);

        Dice dice = new Dice();
        addObject(dice,33,31);
        Dice dice2 = new Dice();
        addObject(dice2,97,31);
    }
}
