import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Dice here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Dice extends Actor
{
    /**
     * Act - do whatever the Dice wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */ 
    String[] Dice = null; //Declared an array that is named Dice.
    public int diceValue; //diceValue stores the number that the dice roll outputs
    private int currentPlayer = 0;
    public Dice() //Made by Gracy Sutaria
    {
        setImage("Dice.png");
        Dice = new String[6];
        Dice[0] = "Dice1.png";
        Dice[1] = "Dice2.png";
        Dice[2] = "Dice3.png";
        Dice[3] = "Dice4.png";
        Dice[4] = "Dice5.png";
        Dice[5] = "Dice6.png";
    }
    public void act()
    {
        clicked();
        //System.out.println(diceValue); 
        //Simply kept on printing 0's in the terminal and seemed pointless to keep when the variable is already set to 0
    }
    public void clicked()
    {
       if (Greenfoot.mouseClicked(this))
       {
           for(int shake = 0; shake < 10; shake ++)
            {
                 turn(300);
                 Greenfoot.delay(10);
            }
           int roll = Greenfoot.getRandomNumber(Dice.length); 
           setImage(Dice[roll]);
           diceValue += roll + 1; 
           if (currentPlayer == 0){
           getWorld().getObjects(Ant.class).get(0).moveForward(diceValue); //move based on the dice number and if touching the game piece
           currentPlayer = 1;
           }
           else{
           getWorld().getObjects(Ant2.class).get(0).moveForward(diceValue); //move based on the dice number and if touching the game piece
           currentPlayer = 0;
           }
           //getWorld().getObjects(Ant.class).get(0).moveForward(diceValue); //move based on the dice number and if touching the game piece
           diceValue = 0; //resets the value so you can roll again*/
       }
    }
}
